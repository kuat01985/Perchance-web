# SwapLab.net Android APK Build Package
App: Perchance Vault Browser
App ID: org.perchance.vaultbrowser
Engine: Capacitor 8.x

## How to Build on https://public.swaplab.net/?utm_source=chatgpt.com:
1. Visit https://public.swaplab.net/?utm_source=chatgpt.com
2. Select Platform: "Android"
3. Select Project Framework Type: "Capacitor"
4. Under "Project Source", choose "Upload .zip"
5. Drag and drop this .zip file into the upload box
6. (Optional) Select Target Android API Level (e.g. API 34+ or Default)
7. Click "Build APK"
8. Wait ~60 seconds for the public runner to generate your APK and download!
